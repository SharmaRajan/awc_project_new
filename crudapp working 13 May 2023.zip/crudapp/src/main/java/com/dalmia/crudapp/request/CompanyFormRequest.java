package com.dalmia.crudapp.request;

import com.dalmia.crudapp.entity.IndustrySector;

public class CompanyFormRequest {

    private String companyName;

    private IndustrySector industrySector;

    private String presence;

    private long totalNoOfFacility;

    public CompanyFormRequest() {
    }

    public CompanyFormRequest(String companyName, IndustrySector industrySector,
                              String presence, long totalNoOfFacility) {
        this.companyName = companyName;
        this.industrySector = industrySector;
        this.presence = presence;
        this.totalNoOfFacility = totalNoOfFacility;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public IndustrySector getIndustrySector() {
        return industrySector;
    }

    public void setIndustrySector(IndustrySector industrySector) {
        this.industrySector = industrySector;
    }

    public String getPresence() {
        return presence;
    }

    public void setPresence(String presence) {
        this.presence = presence;
    }

    public long getTotalNoOfFacility() {
        return totalNoOfFacility;
    }

    public void setTotalNoOfFacility(long totalNoOfFacility) {
        this.totalNoOfFacility = totalNoOfFacility;
    }
}
