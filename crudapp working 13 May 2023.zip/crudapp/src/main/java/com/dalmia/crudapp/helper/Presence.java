package com.dalmia.crudapp.helper;

public enum Presence {

    PANINDIA,
    REGIONAL

}
