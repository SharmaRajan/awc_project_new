package com.dalmia.crudapp.entity;

public class User {
}
