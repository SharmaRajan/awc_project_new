package com.dalmia.greenfuel.entity;

public class User {
}
